#!/usr/bin/python

from statistics import mean, median
from scipy import stats
import logging, argparse, csv, os, sys, re, datetime, json
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import pandas as pd

logging.basicConfig(level=getattr(logging, "INFO", None))


csvFileXACMLWithDM = "microbenchmarks/XACML/results.csv"
csvFileCryptoAC = "microbenchmarks/CryptoAC/results.csv"


# Check all files exist
if (not os.path.exists(csvFileXACMLWithDM)):
    logging.error("Results file " + csvFileXACMLWithDM + " does not exist")
    sys.exit(1)
if (not os.path.exists(csvFileCryptoAC)):
    logging.error("Results file " + csvFileCryptoAC + " does not exist")
    sys.exit(1)


# Filter the results to consider only workflows
# that were completed during the evaluation by
# collecting the ID of the completed workflows
completedWorkflowsXACMLWithDM = []
logging.info("Getting the ID of completed workflows from the results file of XACML")
logging.info("Parsing file " + csvFileXACMLWithDM)
with open(csvFileXACMLWithDM, 'r') as file:
    resultsDict = csv.DictReader(file)
    for row in resultsDict:
        entry = dict(row)
        if (entry["Type"] == "WorkflowCompleted"):
            completedWorkflowsXACMLWithDM.append(entry["Name"])
completedWorkflowsCryptoAC = []
logging.info("Getting the ID of completed workflows from the results file of CryptoAC")
logging.info("Parsing file " + csvFileCryptoAC)
with open(csvFileCryptoAC, 'r') as file:
    resultsDict = csv.DictReader(file)
    for row in resultsDict:
        entry = dict(row)
        if (entry["Type"] == "WorkflowCompleted"):
            completedWorkflowsCryptoAC.append(entry["Name"])
    



# Read the individual responde time for each (group of)
# requests of each instance of (completed) workflow executed

# Store the results in a dictionary; the key of the dictionary is 
# the number of users involved, the value is another dictionary.
# This dictionary has one entry for each workflow that was completed
# during the experimentation. The value corresponding to each of the
# completed workflows is the execution time of the worfklow
logging.info("Reading the individual results from the CSV of XACML")
individualResultsXACMLWithDM = {}
logging.info("Parsing file " + csvFileXACMLWithDM)
currentIndividualResultsXACMLWithDM = {}
with open(csvFileXACMLWithDM, 'r') as file:
    resultsDict = csv.DictReader(file)
    for row in resultsDict:
        entry = dict(row)
        if (
            (entry["Type"] == "DELETE" 
            or 
            entry["Type"] == "POST"
            or
            entry["Type"] == "PATCH"
            or
            entry["Type"] == "PUT"
            or
            entry["Type"] == "GET")
            and
            entry["Name"].startswith("/workflow?id=")
        ):
            workflowName = entry["Name"].split("[")[1].split("]")[0]
            if (workflowName in completedWorkflowsXACMLWithDM):
                if (workflowName not in currentIndividualResultsXACMLWithDM):
                    currentIndividualResultsXACMLWithDM[workflowName] = 0
                currentIndividualResultsXACMLWithDM[workflowName] += round(float(entry["Average Response Time"])*float(entry["Request Count"]), 2)
individualResultsXACMLWithDM = currentIndividualResultsXACMLWithDM
individualResultsCryptoAC = {}
logging.info("Reading the individual results from the CSV of CryptoAC")
logging.info("Parsing file " + csvFileCryptoAC)
currentIndividualResultsCryptoAC = {}
with open(csvFileCryptoAC, 'r') as file:
    resultsDict = csv.DictReader(file)
    for row in resultsDict:
        entry = dict(row)
        if (
            (entry["Type"] == "DELETE" 
            or 
            entry["Type"] == "POST"
            or
            entry["Type"] == "PATCH"
            or
            entry["Type"] == "PUT"
            or
            entry["Type"] == "GET")
            and
            entry["Name"].startswith("/workflow?id=")
        ):
            workflowName = entry["Name"].split("[")[1].split("]")[0]
            if (workflowName in completedWorkflowsCryptoAC):
                if (workflowName not in currentIndividualResultsCryptoAC):
                    currentIndividualResultsCryptoAC[workflowName] = 0
                currentIndividualResultsCryptoAC[workflowName] += round(float(entry["Average Response Time"])*float(entry["Request Count"]), 2)
individualResultsCryptoAC = currentIndividualResultsCryptoAC




# Aggregate the individual results of the workflows of XACML and CryptoAC

# Store the results in a dictionary; the key of the dictionary is 
# the number of users involved, the value is another dictionary.
# This dictionary has one entry for each of the three
# workflows in the experimentation. The value corresponding
# to each workflow is the list of the measurements of
# the workflow (i.e., the execution time of the worfklow)
# calculated by aggregating the individual results of all workflows
logging.info("Aggregating the individual results from the CSV of XACML")
aggregatedResultsXACMLWithDM = {}
individualResultXACMLWithDM = individualResultsXACMLWithDM
currentAggregatedResultsXACMLWithDM = {}
for workflowXACMLWithDMIndividualResult in individualResultXACMLWithDM:
    workflowName = workflowXACMLWithDMIndividualResult.split("workflowID_")[1].split("_pathID_")[0]
    if (workflowName not in currentAggregatedResultsXACMLWithDM):
        currentAggregatedResultsXACMLWithDM[workflowName] = []
    currentAggregatedResultsXACMLWithDM[workflowName].append(round(float(individualResultXACMLWithDM[workflowXACMLWithDMIndividualResult]), 2))
aggregatedResultsXACMLWithDM = currentAggregatedResultsXACMLWithDM
logging.info("Aggregating the individual results from the CSV of CryptoAC")
aggregatedResultsCryptoAC = {}
individualResultCryptoAC = individualResultsCryptoAC
currentAggregatedResultsCryptoAC = {}
for workflowCryptoACIndividualResult in individualResultCryptoAC:
    workflowName = workflowCryptoACIndividualResult.split("workflowID_")[1].split("_pathID_")[0]
    if (workflowName not in currentAggregatedResultsCryptoAC):
        currentAggregatedResultsCryptoAC[workflowName] = []
    currentAggregatedResultsCryptoAC[workflowName].append(round(float(individualResultCryptoAC[workflowCryptoACIndividualResult]), 2))
aggregatedResultsCryptoAC = currentAggregatedResultsCryptoAC


# Parse the aggregated results of XACML and CryptoAC
logging.info("Compute statistics on workflow results of XACML")
averageValuesXACML = {}
aggregatedResultXACMLWithDM = aggregatedResultsXACMLWithDM
for workflowName in aggregatedResultXACMLWithDM:
    currentAggregatedData = aggregatedResultXACMLWithDM[workflowName]
    aggregatedMaxValue = round(float(max(currentAggregatedData)), 2) 
    aggregatedMinValue = round(float(min(currentAggregatedData)), 2) 
    aggregatedAvgValue = round(float(mean(currentAggregatedData)), 2) 
    aggregatedMedianValue = round(float(median(currentAggregatedData)), 2) 
    logging.info("[AGGREGATED] XACMLWithDM workflow " 
        + str(workflowName)
        + ": min "
        + str(aggregatedMinValue)
        + ", max "
        + str(aggregatedMaxValue)
        + ", avg "
        + str(aggregatedAvgValue)
        + ", median "
        + str(aggregatedMedianValue)
    )
    if (workflowName not in averageValuesXACML):
        averageValuesXACML[workflowName] = []
    averageValuesXACML[workflowName].append(aggregatedAvgValue)
    logging.info("----- ----- ----- ----- ----- ----- ")
logging.info("Compute statistics on workflow results of CryptoAC")
averageValuesCryptoAC = {}
aggregatedResultCryptoAC = aggregatedResultsCryptoAC
for workflowName in aggregatedResultCryptoAC:
    currentAggregatedData = aggregatedResultCryptoAC[workflowName]
    aggregatedMaxValue = round(float(max(currentAggregatedData)), 2) 
    aggregatedMinValue = round(float(min(currentAggregatedData)), 2) 
    aggregatedAvgValue = round(float(mean(currentAggregatedData)), 2) 
    aggregatedMedianValue = round(float(median(currentAggregatedData)), 2) 
    logging.info("[AGGREGATED] CryptoAC workflow " 
        + str(workflowName)
        + ": min "
        + str(aggregatedMinValue)
        + ", max "
        + str(aggregatedMaxValue)
        + ", avg "
        + str(aggregatedAvgValue)
        + ", median "
        + str(aggregatedMedianValue)
    )
    if (workflowName not in averageValuesCryptoAC):
        averageValuesCryptoAC[workflowName] = []
    averageValuesCryptoAC[workflowName].append(aggregatedAvgValue)
    logging.info("----- ----- ----- ----- ----- ----- ")
