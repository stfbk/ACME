#!/usr/bin/python

from statistics import mean, median
from scipy import stats
import logging, argparse, csv, os, sys, re, datetime, json
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import pandas as pd

logging.basicConfig(level=getattr(logging, "INFO", None))


# Compute regression model
def getModel(x):
  return slope * x + intercept


# Get label based on the number of users
def getLabel(numberOfUsers):
    return str(numberOfUsers) + " Users"

csvFilesOPA = {
    1:"5/OPAWithDM/results.csv",
    2:"6/OPAWithDM/results.csv",
    3:"7/OPAWithDM/results.csv",
    4:"8/OPAWithDM/results.csv",
    5:"9/OPAWithDM/results.csv",
    6:"10/OPAWithDM/results.csv",
}
csvFilesXACML = {
    1:"5/XACMLWithDM/results.csv",
    2:"6/XACMLWithDM/results.csv",
    3:"7/XACMLWithDM/results.csv",
    4:"8/XACMLWithDM/results.csv",
    5:"9/XACMLWithDM/results.csv",
    6:"10/XACMLWithDM/results.csv",
}
csvFilesCryptoAC = {
    1:"5/CryptoAC/results.csv",
    2:"6/CryptoAC/results.csv",
    3:"7/CryptoAC/results.csv",
    4:"8/CryptoAC/results.csv",
    5:"9/CryptoAC/results.csv",
    6:"10/CryptoAC/results.csv",
}

reportFilesOPAWithDM = {
    1:"5/OPAWithDM/report.html",
    2:"6/OPAWithDM/report.html",
    3:"7/OPAWithDM/report.html",
    4:"8/OPAWithDM/report.html",
    5:"9/OPAWithDM/report.html",
    6:"10/OPAWithDM/report.html"
}
reportFilesXACMLWithDM = {
    1:"5/XACMLWithDM/report.html",
    2:"6/XACMLWithDM/report.html",
    3:"7/XACMLWithDM/report.html",
    4:"8/XACMLWithDM/report.html",
    5:"9/XACMLWithDM/report.html",
    6:"10/XACMLWithDM/report.html"
}
reportFilesCryptoAC = {
    1:"5/CryptoAC/report.html",
    2:"6/CryptoAC/report.html",
    3:"7/CryptoAC/report.html",
    4:"8/CryptoAC/report.html",
    5:"9/CryptoAC/report.html",
    6:"10/CryptoAC/report.html"
}


array5To10 = np.array([i for i in range(1, 7)])


# Check all files exist
logging.info("Checking that all files exist")
for numberOfUsers in range(1, 7):
    csvFileOPA = csvFilesOPA[numberOfUsers]
    if (not os.path.exists(csvFileOPA)):
        logging.error("Results file " + csvFileOPA + " does not exist")
        sys.exit(1)
    csvFileXACML = csvFilesXACML[numberOfUsers]
    if (not os.path.exists(csvFileXACML)):
        logging.error("Results file " + csvFileXACML + " does not exist")
        sys.exit(1)
    csvFileCryptoAC = csvFilesCryptoAC[numberOfUsers]
    if (not os.path.exists(csvFileCryptoAC)):
        logging.error("Results file " + csvFileCryptoAC + " does not exist")
        sys.exit(1)
    reportFileOPAWithDM = reportFilesOPAWithDM[numberOfUsers]
    if (not os.path.exists(reportFileOPAWithDM)):
        logging.error("Report file " + reportFileOPAWithDM + " does not exist")
        sys.exit(1)
    reportFileXACMLWithDM = reportFilesXACMLWithDM[numberOfUsers]
    if (not os.path.exists(reportFileXACMLWithDM)):
        logging.error("Report file " + reportFileXACMLWithDM + " does not exist")
        sys.exit(1)
    reportFileCryptoAC = reportFilesCryptoAC[numberOfUsers]
    if (not os.path.exists(reportFileCryptoAC)):
        logging.error("Report file " + reportFileCryptoAC + " does not exist")
        sys.exit(1)




# Filter the results to consider only workflows
# that were completed during the evaluation by
# collecting the ID of the completed workflows
completedWorkflowsOPAWithDM = []
logging.info("Getting the ID of completed workflows from the results file of OPA")
for numberOfUsers in range(1, 7):
    csvFileOPA = csvFilesOPA[numberOfUsers]
    logging.info("Parsing file " + csvFileOPA)
    with open(csvFileOPA, 'r') as file:
        resultsDict = csv.DictReader(file)
        for row in resultsDict:
            entry = dict(row)
            if (entry["Type"] == "WorkflowCompleted"):
                completedWorkflowsOPAWithDM.append(entry["Name"])
completedWorkflowsXACMLWithDM = []
logging.info("Getting the ID of completed workflows from the results file of XACML")
for numberOfUsers in range(1, 7):
    csvFileXACML = csvFilesXACML[numberOfUsers]
    logging.info("Parsing file " + csvFileXACML)
    with open(csvFileXACML, 'r') as file:
        resultsDict = csv.DictReader(file)
        for row in resultsDict:
            entry = dict(row)
            if (entry["Type"] == "WorkflowCompleted"):
                completedWorkflowsXACMLWithDM.append(entry["Name"])
completedWorkflowsCryptoAC = []
logging.info("Getting the ID of completed workflows from the results file of CryptoAC")
for numberOfUsers in range(1, 7):
    csvFileCryptoAC = csvFilesCryptoAC[numberOfUsers]
    logging.info("Parsing file " + csvFileCryptoAC)
    with open(csvFileCryptoAC, 'r') as file:
        resultsDict = csv.DictReader(file)
        for row in resultsDict:
            entry = dict(row)
            if (entry["Type"] == "WorkflowCompleted"):
                completedWorkflowsCryptoAC.append(entry["Name"])
    



# Read the individual responde time for each (group of)
# requests of each instance of (completed) workflow executed
logging.info("Reading the individual results from the CSV of OPA")

# Store the results in a dictionary; the key of the dictionary is 
# the number of users involved, the value is another dictionary.
# This dictionary has one entry for each workflow that was completed
# during the experimentation. The value corresponding to each of the
# completed workflows is the execution time of the worfklow
individualResultsOPAWithDM = {}
for numberOfUsers in range(1, 7):
    csvFileOPA = csvFilesOPA[numberOfUsers]
    logging.info("Parsing file " + csvFileOPA)
    currentIndividualResultsOPAWithDM = {}
    with open(csvFileOPA, 'r') as file:
        resultsDict = csv.DictReader(file)
        for row in resultsDict:
            entry = dict(row)
            if (
                (entry["Type"] == "DELETE" 
                or 
                entry["Type"] == "POST"
                or
                entry["Type"] == "PATCH"
                or
                entry["Type"] == "GET")
                and
                entry["Name"].startswith("/workflow?id=")
            ):
                workflowName = entry["Name"].split("[")[1].split("]")[0]
                if (workflowName in completedWorkflowsOPAWithDM):
                    if (workflowName not in currentIndividualResultsOPAWithDM):
                        currentIndividualResultsOPAWithDM[workflowName] = 0
                    currentIndividualResultsOPAWithDM[workflowName] += round(float(entry["Average Response Time"])*float(entry["Request Count"]), 2)
    individualResultsOPAWithDM[numberOfUsers] = currentIndividualResultsOPAWithDM
logging.info("Reading the individual results from the CSV of XACML")
individualResultsXACMLWithDM = {}
for numberOfUsers in range(1, 7):
    csvFileXACML = csvFilesXACML[numberOfUsers]
    logging.info("Parsing file " + csvFileXACML)
    currentIndividualResultsXACMLWithDM = {}
    with open(csvFileXACML, 'r') as file:
        resultsDict = csv.DictReader(file)
        for row in resultsDict:
            entry = dict(row)
            if (
                (entry["Type"] == "DELETE" 
                or 
                entry["Type"] == "POST"
                or
                entry["Type"] == "PATCH"
                or
                entry["Type"] == "GET")
                and
                entry["Name"].startswith("/workflow?id=")
            ):
                workflowName = entry["Name"].split("[")[1].split("]")[0]
                if (workflowName in completedWorkflowsXACMLWithDM):
                    if (workflowName not in currentIndividualResultsXACMLWithDM):
                        currentIndividualResultsXACMLWithDM[workflowName] = 0
                    currentIndividualResultsXACMLWithDM[workflowName] += round(float(entry["Average Response Time"])*float(entry["Request Count"]), 2)
    individualResultsXACMLWithDM[numberOfUsers] = currentIndividualResultsXACMLWithDM
individualResultsCryptoAC = {}
logging.info("Reading the individual results from the CSV of CryptoAC")
for numberOfUsers in range(1, 7):
    csvFileCryptoAC = csvFilesCryptoAC[numberOfUsers]
    logging.info("Parsing file " + csvFileCryptoAC)
    currentIndividualResultsCryptoAC = {}
    with open(csvFileCryptoAC, 'r') as file:
        resultsDict = csv.DictReader(file)
        for row in resultsDict:
            entry = dict(row)
            if (
                (entry["Type"] == "DELETE" 
                or 
                entry["Type"] == "POST"
                or
                entry["Type"] == "PATCH"
                or
                entry["Type"] == "GET")
                and
                entry["Name"].startswith("/workflow?id=")
            ):
                workflowName = entry["Name"].split("[")[1].split("]")[0]
                if (workflowName in completedWorkflowsCryptoAC):
                    if (workflowName not in currentIndividualResultsCryptoAC):
                        currentIndividualResultsCryptoAC[workflowName] = 0
                    currentIndividualResultsCryptoAC[workflowName] += round(float(entry["Average Response Time"])*float(entry["Request Count"]), 2)
    individualResultsCryptoAC[numberOfUsers] = currentIndividualResultsCryptoAC




# Aggregate the individual results of the workflows of OPA, XACML and CryptoAC
logging.info("Aggregating the individual results from the CSV of OPA")

# Store the results in a dictionary; the key of the dictionary is 
# the number of users involved, the value is another dictionary.
# This dictionary has one entry for each of the three
# workflows in the experimentation. The value corresponding
# to each workflow is the list of the measurements of
# the workflow (i.e., the execution time of the worfklow)
# calculated by aggregating the individual results of all workflows
aggregatedResultsOPAWithDM = {}
for numberOfUsers in range(1, 7):
    individualResultOPAWithDM = individualResultsOPAWithDM[numberOfUsers]
    currentAggregatedResultsOPAWithDM = {}
    for workflowOPAWithDMIndividualResult in individualResultOPAWithDM:
        workflowName = workflowOPAWithDMIndividualResult.split("workflowID_")[1].split("_pathID_")[0]
        if (workflowName not in currentAggregatedResultsOPAWithDM):
            currentAggregatedResultsOPAWithDM[workflowName] = []
        currentAggregatedResultsOPAWithDM[workflowName].append(round(float(individualResultOPAWithDM[workflowOPAWithDMIndividualResult]), 2))
    aggregatedResultsOPAWithDM[numberOfUsers] = currentAggregatedResultsOPAWithDM
logging.info("Aggregating the individual results from the CSV of XACML")
aggregatedResultsXACMLWithDM = {}
for numberOfUsers in range(1, 7):
    individualResultXACMLWithDM = individualResultsXACMLWithDM[numberOfUsers]
    currentAggregatedResultsXACMLWithDM = {}
    for workflowXACMLWithDMIndividualResult in individualResultXACMLWithDM:
        workflowName = workflowXACMLWithDMIndividualResult.split("workflowID_")[1].split("_pathID_")[0]
        if (workflowName not in currentAggregatedResultsXACMLWithDM):
            currentAggregatedResultsXACMLWithDM[workflowName] = []
        currentAggregatedResultsXACMLWithDM[workflowName].append(round(float(individualResultXACMLWithDM[workflowXACMLWithDMIndividualResult]), 2))
    aggregatedResultsXACMLWithDM[numberOfUsers] = currentAggregatedResultsXACMLWithDM
logging.info("Aggregating the individual results from the CSV of CryptoAC")
aggregatedResultsCryptoAC = {}
for numberOfUsers in range(1, 7):
    individualResultCryptoAC = individualResultsCryptoAC[numberOfUsers]
    currentAggregatedResultsCryptoAC = {}
    for workflowCryptoACIndividualResult in individualResultCryptoAC:
        workflowName = workflowCryptoACIndividualResult.split("workflowID_")[1].split("_pathID_")[0]
        if (workflowName not in currentAggregatedResultsCryptoAC):
            currentAggregatedResultsCryptoAC[workflowName] = []
        currentAggregatedResultsCryptoAC[workflowName].append(round(float(individualResultCryptoAC[workflowCryptoACIndividualResult]), 2))
    aggregatedResultsCryptoAC[numberOfUsers] = currentAggregatedResultsCryptoAC




# Parse the aggregated results of OPA, XACML and CryptoAC
logging.info("Compute statistics on workflow results of OPA")
averageValuesOPA = {}
for numberOfUsers in range(1, 7):
    aggregatedResultOPAWithDM = aggregatedResultsOPAWithDM[numberOfUsers]
    for workflowName in aggregatedResultOPAWithDM:
        currentAggregatedData = aggregatedResultOPAWithDM[workflowName]
        aggregatedMaxValue = round(float(max(currentAggregatedData)), 2) 
        aggregatedMinValue = round(float(min(currentAggregatedData)), 2) 
        aggregatedAvgValue = round(float(mean(currentAggregatedData)), 2) 
        aggregatedMedianValue = round(float(median(currentAggregatedData)), 2) 
        logging.info("[AGGREGATED] OPAWithDM workflow " 
            + str(workflowName)
            + " with "
            + str(numberOfUsers+4)
            + " users: min "
            + str(aggregatedMinValue)
            + ", max "
            + str(aggregatedMaxValue)
            + ", avg "
            + str(aggregatedAvgValue)
            + ", median "
            + str(aggregatedMedianValue)
        )
        if (workflowName not in averageValuesOPA):
            averageValuesOPA[workflowName] = []
        averageValuesOPA[workflowName].append(aggregatedAvgValue)
        logging.info("----- ----- ----- ----- ----- ----- ")
logging.info("Compute statistics on workflow results of XACML")
averageValuesXACML = {}
for numberOfUsers in range(1, 7):
    aggregatedResultXACMLWithDM = aggregatedResultsXACMLWithDM[numberOfUsers]
    for workflowName in aggregatedResultXACMLWithDM:
        currentAggregatedData = aggregatedResultXACMLWithDM[workflowName]
        aggregatedMaxValue = round(float(max(currentAggregatedData)), 2) 
        aggregatedMinValue = round(float(min(currentAggregatedData)), 2) 
        aggregatedAvgValue = round(float(mean(currentAggregatedData)), 2) 
        aggregatedMedianValue = round(float(median(currentAggregatedData)), 2) 
        logging.info("[AGGREGATED] XACMLWithDM workflow " 
            + str(workflowName)
            + " with "
            + str(numberOfUsers+4)
            + " users: min "
            + str(aggregatedMinValue)
            + ", max "
            + str(aggregatedMaxValue)
            + ", avg "
            + str(aggregatedAvgValue)
            + ", median "
            + str(aggregatedMedianValue)
        )
        if (workflowName not in averageValuesXACML):
            averageValuesXACML[workflowName] = []
        averageValuesXACML[workflowName].append(aggregatedAvgValue)
        logging.info("----- ----- ----- ----- ----- ----- ")
logging.info("Compute statistics on workflow results of CryptoAC")
averageValuesCryptoAC = {}
for numberOfUsers in range(1, 7):
    aggregatedResultCryptoAC = aggregatedResultsCryptoAC[numberOfUsers]
    for workflowName in aggregatedResultCryptoAC:
        currentAggregatedData = aggregatedResultCryptoAC[workflowName]
        aggregatedMaxValue = round(float(max(currentAggregatedData)), 2) 
        aggregatedMinValue = round(float(min(currentAggregatedData)), 2) 
        aggregatedAvgValue = round(float(mean(currentAggregatedData)), 2) 
        aggregatedMedianValue = round(float(median(currentAggregatedData)), 2) 
        logging.info("[AGGREGATED] CryptoAC workflow " 
            + str(workflowName)
            + " with "
            + str(numberOfUsers+4)
            + " users: min "
            + str(aggregatedMinValue)
            + ", max "
            + str(aggregatedMaxValue)
            + ", avg "
            + str(aggregatedAvgValue)
            + ", median "
            + str(aggregatedMedianValue)
        )
        if (workflowName not in averageValuesCryptoAC):
            averageValuesCryptoAC[workflowName] = []
        averageValuesCryptoAC[workflowName].append(aggregatedAvgValue)
        logging.info("----- ----- ----- ----- ----- ----- ")




# Plot the results of each workflow separately (distinguish 
# between OPA, XACML and CryptoAC)
logging.info("Plotting aggregated workflows for OPA")
aggregatedResultsByWorkflowOPAWithDM = {}
for numberOfUsers in range(1, 7):
    logging.info("Getting results of repetition with " + str(numberOfUsers) + " users")
    aggregatedResultOPAWithDM = aggregatedResultsOPAWithDM[numberOfUsers]
    for workflowName in aggregatedResultOPAWithDM:
        if (workflowName not in aggregatedResultsByWorkflowOPAWithDM):
            aggregatedResultsByWorkflowOPAWithDM[workflowName] = []
        aggregatedResultsByWorkflowOPAWithDM[workflowName].append(aggregatedResultOPAWithDM[workflowName])
for workflowName in aggregatedResultsByWorkflowOPAWithDM:
    figOPA = plt.figure(figsize =(12, 8))
    figOPA.suptitle("OPAWithDM - Worflow \"" + workflowName.replace("_", " ") + "\"", fontsize=14, fontweight='bold')
    plt.title('OPAWithDM Average Workflow Execution Time')
    plt.xlabel('Users')
    plt.ylabel('Execution Time (ms)')
    plt.boxplot(
        x = aggregatedResultsByWorkflowOPAWithDM[workflowName],
        patch_artist = True,
        showfliers=False,
        showmeans=True,
        meanline=False,
        zorder=0,
        boxprops=dict(
            facecolor="#74b9ff", 
            edgecolor="#2d3436",
        ),
        medianprops=dict(
            linestyle='--',
            color="#2d3436"
        ),
        meanprops=dict(
            marker='D', 
            markeredgecolor='#636e72',
            markerfacecolor='#fab1a0'
        )
    )

    # Compute regression on average values
    slope, intercept, r, p, std_err = stats.linregress(
        array5To10,
        averageValuesOPA[workflowName]
    )
    logging.info("OPA, workflow "
        + workflowName
        + ": slope " 
        + str(slope) 
        + ", intercept " 
        + str(intercept)
    )
    plt.plot(
        array5To10, 
        list(map(getModel, array5To10)),
        label=getLabel(numberOfUsers),
        linewidth=2,
        zorder=10,
        color='#2d3436'
    )
    plt.xticks(ticks=[1, 2, 3, 4, 5, 6], labels=["5", "6", "7", "8", "9", "10"])
    plt.show()
logging.info("Plotting aggregated workflows for XACML")
aggregatedResultsByWorkflowXACMLWithDM = {}
for numberOfUsers in range(1, 7):
    logging.info("Getting results of repetition with " + str(numberOfUsers) + " users")
    aggregatedResultXACMLWithDM = aggregatedResultsXACMLWithDM[numberOfUsers]
    for workflowName in aggregatedResultXACMLWithDM:
        if (workflowName not in aggregatedResultsByWorkflowXACMLWithDM):
            aggregatedResultsByWorkflowXACMLWithDM[workflowName] = []
        aggregatedResultsByWorkflowXACMLWithDM[workflowName].append(aggregatedResultXACMLWithDM[workflowName])
for workflowName in aggregatedResultsByWorkflowXACMLWithDM:
    figXACML = plt.figure(figsize =(12, 8))
    figXACML.suptitle("XACMLWithDM - Worflow \"" + workflowName.replace("_", " ") + "\"", fontsize=14, fontweight='bold')
    plt.title('XACMLWithDM Average Workflow Execution Time')
    plt.xlabel('Users')
    plt.ylabel('Execution Time (ms)')
    plt.boxplot(
        x = aggregatedResultsByWorkflowXACMLWithDM[workflowName],
        patch_artist = True,
        showfliers=False,
        showmeans=True,
        meanline=False,
        zorder=0,
        boxprops=dict(
            facecolor="#74b9ff", 
            edgecolor="#2d3436",
        ),
        medianprops=dict(
            linestyle='--',
            color="#2d3436"
        ),
        meanprops=dict(
            marker='D', 
            markeredgecolor='#636e72',
            markerfacecolor='#fab1a0'
        )
    )

    # Compute regression on average values
    slope, intercept, r, p, std_err = stats.linregress(
        array5To10,
        averageValuesXACML[workflowName]
    )
    logging.info("XACML, workflow "
        + workflowName
        + ": slope " 
        + str(slope) 
        + ", intercept " 
        + str(intercept)
    )
    plt.plot(
        array5To10, 
        list(map(getModel, array5To10)),
        label=getLabel(numberOfUsers),
        linewidth=2,
        zorder=10,
        color='#2d3436'
    )
    plt.xticks(ticks=[1, 2, 3, 4, 5, 6], labels=["5", "6", "7", "8", "9", "10"])
    plt.show()
logging.info("Plotting aggregated workflows for CryptoAC")
aggregatedResultsByWorkflowCryptoAC = {}
for numberOfUsers in range(1, 7):
    logging.info("Getting results of repetition with " + str(numberOfUsers) + " users")
    aggregatedResultCryptoAC = aggregatedResultsCryptoAC[numberOfUsers]
    for workflowName in aggregatedResultCryptoAC:
        if (workflowName not in aggregatedResultsByWorkflowCryptoAC):
            aggregatedResultsByWorkflowCryptoAC[workflowName] = []
        aggregatedResultsByWorkflowCryptoAC[workflowName].append(aggregatedResultCryptoAC[workflowName])

for workflowName in aggregatedResultsByWorkflowCryptoAC:
    figCryptoAC = plt.figure(figsize =(12, 8))
    figCryptoAC.suptitle("CryptoAC - Worflow \"" + workflowName.replace("_", " ") + "\"", fontsize=14, fontweight='bold')
    plt.title('CryptoAC Average Workflow Execution Time')
    plt.xlabel('Users')
    plt.ylabel('Execution Time (ms)')
    plt.boxplot(
        x = aggregatedResultsByWorkflowCryptoAC[workflowName],
        patch_artist = True,
        showfliers=False,
        showmeans=True,
        meanline=False,
        zorder=0,
        boxprops=dict(
            facecolor="#74b9ff", 
            edgecolor="#2d3436",
        ),
        medianprops=dict(
            linestyle='--',
            color="#2d3436"
        ),
        meanprops=dict(
            marker='D', 
            markeredgecolor='#636e72',
            markerfacecolor='#fab1a0'
        )
    )

    # Compute regression on average values
    slope, intercept, r, p, std_err = stats.linregress(
        array5To10,
        averageValuesCryptoAC[workflowName]
    )
    logging.info("CryptoAC, workflow "
        + workflowName
        + ": slope " 
        + str(slope) 
        + ", intercept " 
        + str(intercept)
    )
    plt.plot(
        array5To10, 
        list(map(getModel, array5To10)),
        label=getLabel(numberOfUsers),
        linewidth=2,
        zorder=10,
        color='#2d3436'
    )
    plt.xticks(ticks=[1, 2, 3, 4, 5, 6], labels=["5", "6", "7", "8", "9", "10"])
    plt.show()
















# Plot the results of each workflow across OPA, XACML and CryptoAC
logging.info("Plotting aggregated workflows across mechanisms")
i = 0
for workflowName in aggregatedResultsByWorkflowCryptoAC:
    i = i + 1
    figOPA = plt.figure(figsize =(12, 8))
    figOPA.suptitle("Worflow \"" + workflowName.replace("_", " ") + "\"", fontsize=14, fontweight='bold')
    plt.title('Average Workflow Execution Time')
    plt.xlabel('Users')
    plt.ylabel('Execution Time (ms)')
    plt.boxplot(
        x = aggregatedResultsByWorkflowOPAWithDM[workflowName],
        patch_artist=False,
        showfliers=False,
        whis=0,
        showbox=False,
        showcaps=False,
        showmeans=True,
        meanline=False,
        zorder=1,
        medianprops=dict(
            linewidth=0,
            linestyle=None
        ),  
        meanprops=dict(
            marker='o', 
            markersize=12,
            markeredgecolor='#000000',
            markerfacecolor='#92cade'
        )
    )
    plt.boxplot(
        x = aggregatedResultsByWorkflowXACMLWithDM[workflowName],
        patch_artist=False,
        showfliers=False,
        whis=0,
        showbox=False,
        showcaps=False,
        showmeans=True,
        meanline=False,
        zorder=1,
        medianprops=dict(
            linewidth=0,
            linestyle=None
        ),  
        meanprops=dict(
            marker='X', 
            markersize=12,
            markeredgecolor='#000000',
            markerfacecolor='#fab1a0'
        )
    )
    plt.boxplot(
        x = aggregatedResultsByWorkflowCryptoAC[workflowName],
        patch_artist=False,
        showfliers=False,
        whis=0,
        showbox=False,
        showcaps=False,
        showmeans=True,
        meanline=False,
        zorder=1,
        medianprops=dict(
            linewidth=0,
            linestyle=None
        ),  
        meanprops=dict(
            marker='s', 
            markersize=12,
            markeredgecolor='#000000',
            markerfacecolor='#c0e8be'
        )
    )

    # Compute regression on average values
    slope, intercept, r, p, std_err = stats.linregress(
        array5To10,
        averageValuesOPA[workflowName]
    )
    plt.plot(
        array5To10, 
        list(map(getModel, array5To10)),
        label=getLabel(numberOfUsers),
        linewidth=2,
        zorder=0,
        color='#2d3436'
    )
    slope, intercept, r, p, std_err = stats.linregress(
        array5To10,
        averageValuesXACML[workflowName]
    )
    plt.plot(
        array5To10, 
        list(map(getModel, array5To10)),
        label=getLabel(numberOfUsers),
        linewidth=2,
        zorder=0,
        color='#2d3436'
    )
    slope, intercept, r, p, std_err = stats.linregress(
        array5To10,
        averageValuesCryptoAC[workflowName]
    )
    plt.plot(
        array5To10, 
        list(map(getModel, array5To10)),
        label=getLabel(numberOfUsers),
        linewidth=2,
        zorder=0,
        color='#2d3436'
    )

    if (i == 1):
        plt.text(3.42, 400, 'OPA')
        plt.text(3.37, 4600, 'XACML')
        plt.text(3.32, 6500, 'CryptoAC')
    elif (i == 2):
        plt.text(3.42, 1100, 'OPA')
        plt.text(3.37, 14500, 'XACML')
        plt.text(3.32, 16900, 'CryptoAC')
    elif (i == 3):
        plt.text(3.42, 1100, 'OPA')
        plt.text(3.37, 17000, 'XACML')
        plt.text(3.32, 19200, 'CryptoAC')
    elif (i == 4):
        plt.text(3.42, 2000, 'OPA')
        plt.text(3.37, 25000, 'XACML')
        plt.text(3.32, 27800, 'CryptoAC')
    elif (i == 5):
        plt.text(3.42, 1200, 'OPA')
        plt.text(3.37, 15900, 'XACML')
        plt.text(3.32, 18500, 'CryptoAC')


    plt.xticks(ticks=[1, 2, 3, 4, 5, 6], labels=["5", "6", "7", "8", "9", "10"])
    plt.show()





























# Get RPS statistics from the report of OPA, XACML and CryptoAC
logging.info("Getting the statistics from the report of OPAWithDM")
statisticsOPAwithDM_RPS = {}
for numberOfUsers in range(1, 7):
    reportFileOPAWithDM = reportFilesOPAWithDM[numberOfUsers]
    logging.info("Parsing file " + reportFileOPAWithDM)
    with open(reportFileOPAWithDM, 'r') as file:
        reportText = file.read()
        statisticsText = re.findall("var stats_history = (.+?);", reportText, re.DOTALL)[0]
        statisticsText = statisticsText.replace(""".map(server_time => new Date(new Date().setUTCHours(...(server_time.split(":")))).toLocaleTimeString())""", "")
        statisticsText = statisticsText.replace(""""markers": [],""", """"markers": []""")
        statisticsJSON = json.loads(statisticsText)
        numberOfDataPoints = len(statisticsJSON["time"])
        rps = []
        for index in range(numberOfDataPoints):
            rps.append(statisticsJSON["current_rps"][index]["value"])

        # Remove the first 12 data points (i.e., the first minute)
        numberOfDataPoints -= 12
        rps = rps[12:]
        currentDataFrame_RPS = pd.DataFrame({
            'date': np.array([5*i for i in range(numberOfDataPoints)]), 
            'rps': rps
        })
        statisticsOPAwithDM_RPS[numberOfUsers] = currentDataFrame_RPS
        maxRPS = round(float(max(rps)), 2) 
        minRPS = round(float(min(rps)), 2) 
        avgRPS = round(float(mean(rps)), 2) 
        medianRPS = round(float(median(rps)), 2) 
        logging.info("[REQUESTS PER SECONDS] OPA, min: " 
            + str(minRPS)
            + ", max "
            + str(maxRPS)
            + ", avg "
            + str(avgRPS)
            + ", median "
            + str(medianRPS)
        )
logging.info("Getting the statistics from the report of XACMLWithDM")
statisticsXACMLwithDM_RPS = {}
for numberOfUsers in range(1, 7):
    reportFileXACMLWithDM = reportFilesXACMLWithDM[numberOfUsers]
    logging.info("Parsing file " + reportFileXACMLWithDM)
    with open(reportFileXACMLWithDM, 'r') as file:
        reportText = file.read()
        statisticsText = re.findall("var stats_history = (.+?);", reportText, re.DOTALL)[0]
        statisticsText = statisticsText.replace(""".map(server_time => new Date(new Date().setUTCHours(...(server_time.split(":")))).toLocaleTimeString())""", "")
        statisticsText = statisticsText.replace(""""markers": [],""", """"markers": []""")
        statisticsJSON = json.loads(statisticsText)
        numberOfDataPoints = len(statisticsJSON["time"])
        rps = []
        for index in range(numberOfDataPoints):
            rps.append(statisticsJSON["current_rps"][index]["value"])

        # Remove the first 12 data points (i.e., the first minute)
        numberOfDataPoints -= 12
        rps = rps[12:]
        currentDataFrame_RPS = pd.DataFrame({
            'date': np.array([5*i for i in range(numberOfDataPoints)]), 
            'rps': rps
        })
        statisticsXACMLwithDM_RPS[numberOfUsers] = currentDataFrame_RPS
        maxRPS = round(float(max(rps)), 2) 
        minRPS = round(float(min(rps)), 2) 
        avgRPS = round(float(mean(rps)), 2) 
        medianRPS = round(float(median(rps)), 2) 
        logging.info("[REQUESTS PER SECONDS] XACML, min: " 
            + str(minRPS)
            + ", max "
            + str(maxRPS)
            + ", avg "
            + str(avgRPS)
            + ", median "
            + str(medianRPS)
        )
logging.info("Getting the statistics from the report of CryptoAC")
statisticsCryptoAC_RPS = {}
for numberOfUsers in range(1, 7):
    reportFileCryptoAC = reportFilesCryptoAC[numberOfUsers]
    logging.info("Parsing file " + reportFileCryptoAC)
    with open(reportFileCryptoAC, 'r') as file:
        reportText = file.read()
        statisticsText = re.findall("var stats_history = (.+?);", reportText, re.DOTALL)[0]
        statisticsText = statisticsText.replace(""".map(server_time => new Date(new Date().setUTCHours(...(server_time.split(":")))).toLocaleTimeString())""", "")
        statisticsText = statisticsText.replace(""""markers": [],""", """"markers": []""")
        statisticsJSON = json.loads(statisticsText)
        numberOfDataPoints = len(statisticsJSON["time"])
        rps = []
        for index in range(numberOfDataPoints):
            rps.append(statisticsJSON["current_rps"][index]["value"])

        # Remove the first 12 data points (i.e., the first minute)
        numberOfDataPoints -= 12
        rps = rps[12:]
        currentDataFrame_RPS = pd.DataFrame({
            'date': np.array([5*i for i in range(numberOfDataPoints)]), 
            'rps': rps
        })
        statisticsCryptoAC_RPS[numberOfUsers] = currentDataFrame_RPS
        maxRPS = round(float(max(rps)), 2) 
        minRPS = round(float(min(rps)), 2) 
        avgRPS = round(float(mean(rps)), 2) 
        medianRPS = round(float(median(rps)), 2) 
        logging.info("[REQUESTS PER SECONDS] CryptoAC, min: " 
            + str(minRPS)
            + ", max "
            + str(maxRPS)
            + ", avg "
            + str(avgRPS)
            + ", median "
            + str(medianRPS)
         )





# Plot the request per second for each user separately (distinguish 
# between OPA, XACML and CryptoAC)
logging.info("Show boxplot of OPAWithDM RPS")
figOPAWithDM = plt.figure(figsize=(12, 8))
plt.title('OPAWithDM Boxplot RPS')
plt.xlabel('Users')
plt.ylabel('RPS')
dataFramesOPAWithDM = []
averageRPSOPA = []
for numberOfUsers in range(1, 7):
    currentDataFrame = statisticsOPAwithDM_RPS[numberOfUsers]
    averageRPSOPA.append(round(float(mean(currentDataFrame.rps)), 2))
    dataFramesOPAWithDM.append(currentDataFrame.rps)
plt.boxplot(
    x = dataFramesOPAWithDM,
    patch_artist = True,
    showfliers=False,
    showmeans=True,
    meanline=False,
    zorder=0,
    boxprops=dict(
        facecolor="#74b9ff", 
        edgecolor="#2d3436",
    ),
    medianprops=dict(
        linestyle='--',
        color="#2d3436"
    ),
    meanprops=dict(
        marker='D', 
        markeredgecolor='#636e72',
        markerfacecolor='#fab1a0'
    )
)
# Compute regression on rps
slope, intercept, r, p, std_err = stats.linregress(
    array5To10,
    averageRPSOPA
)
logging.info("OPA, RPS: slope " 
    + str(slope) 
    + ", intercept " 
    + str(intercept)
)
plt.plot(
    array5To10, 
    list(map(getModel, array5To10)),
    label=getLabel(numberOfUsers),
    linewidth=2,
    zorder=10,
    color='#2d3436'
)
plt.tight_layout()  
plt.xticks(ticks=[1, 2, 3, 4, 5, 6], labels=["5", "6", "7", "8", "9", "10"])
plt.show() 
logging.info("Show boxplot of XACMLWithDM RPS")
figXACMLWithDM = plt.figure(figsize=(12, 8))
plt.title('XACMLWithDM Boxplot RPS')
plt.xlabel('Users')
plt.ylabel('RPS')
dataFramesXACMLWithDM = []
averageRPSXACML = []
for numberOfUsers in range(1, 7):
    currentDataFrame = statisticsXACMLwithDM_RPS[numberOfUsers]
    averageRPSXACML.append(round(float(mean(currentDataFrame.rps)), 2))
    dataFramesXACMLWithDM.append(currentDataFrame.rps)
plt.boxplot(
    x = dataFramesXACMLWithDM,
    patch_artist = True,
    showfliers=False,
    showmeans=True,
    meanline=False,
    zorder=0,
    boxprops=dict(
        facecolor="#74b9ff", 
        edgecolor="#2d3436",
    ),
    medianprops=dict(
        linestyle='--',
        color="#2d3436"
    ),
    meanprops=dict(
        marker='D', 
        markeredgecolor='#636e72',
        markerfacecolor='#fab1a0'
    )
)
# Compute regression on rps
slope, intercept, r, p, std_err = stats.linregress(
    array5To10,
    averageRPSXACML
)
logging.info("XACML, RPS: slope " 
    + str(slope) 
    + ", intercept " 
    + str(intercept)
)
plt.plot(
    array5To10, 
    list(map(getModel, array5To10)),
    label=getLabel(numberOfUsers),
    linewidth=2,
    zorder=10,
    color='#2d3436'
)
plt.tight_layout()  
plt.xticks(ticks=[1, 2, 3, 4, 5, 6], labels=["5", "6", "7", "8", "9", "10"])
plt.show() 
logging.info("Show boxplot of CryptoAC RPS")
figCryptoAC = plt.figure(figsize=(12, 8))
plt.title('CryptoAC Boxplot RPS')
plt.xlabel('Users')
plt.ylabel('RPS')
dataFramesCryptoAC = []
averageRPSCryptoAC = []
for numberOfUsers in range(1, 7):
    currentDataFrame = statisticsCryptoAC_RPS[numberOfUsers]
    averageRPSCryptoAC.append(round(float(mean(currentDataFrame.rps)), 2))
    dataFramesCryptoAC.append(currentDataFrame.rps)
plt.boxplot(
    x = dataFramesCryptoAC,
    patch_artist = True,
    showfliers=False,
    showmeans=True,
    meanline=False,
    zorder=0,
    boxprops=dict(
        facecolor="#74b9ff", 
        edgecolor="#2d3436",
    ),
    medianprops=dict(
        linestyle='--',
        color="#2d3436"
    ),
    meanprops=dict(
        marker='D', 
        markeredgecolor='#636e72',
        markerfacecolor='#fab1a0'
    )
)
# Compute regression on rps
slope, intercept, r, p, std_err = stats.linregress(
    array5To10,
    averageRPSCryptoAC
)
logging.info("CryptoAC, RPS: slope " 
    + str(slope) 
    + ", intercept " 
    + str(intercept)
)
plt.plot(
    array5To10, 
    list(map(getModel, array5To10)),
    label=getLabel(numberOfUsers),
    linewidth=2,
    zorder=10,
    color='#2d3436'
)
plt.tight_layout()  
plt.xticks(ticks=[1, 2, 3, 4, 5, 6], labels=["5", "6", "7", "8", "9", "10"])
plt.show() 

